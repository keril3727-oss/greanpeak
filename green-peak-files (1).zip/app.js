// Green Peak — интерфейсная демо-версия. Операции сохраняются локально в браузере.
const SUPABASE_URL = "https://lrwvmqdtfssxiqfyehyd.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_EzTtzLmOW0dvvLA9wCwmiA_O2Zo1Uv6";
let supabaseClient = null;
try { if (window.supabase && SUPABASE_URL.startsWith("https://") && SUPABASE_PUBLISHABLE_KEY.startsWith("sb_publishable_")) supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY); } catch(e) { console.warn("Supabase init:", e); }

const demoTransactions = [
 {name:"Оплата проекта Nordic Studio",date:"30 окт. 2026",category:"Продажи",type:"income",amount:4250},
 {name:"Закупка оборудования",date:"29 окт. 2026",category:"Закупки",type:"expense",amount:1180},
 {name:"Абонентское обслуживание",date:"28 окт. 2026",category:"Услуги",type:"income",amount:890},
 {name:"Рекламная кампания",date:"27 окт. 2026",category:"Маркетинг",type:"expense",amount:640},
 {name:"Оплата заказа #GP-1042",date:"26 окт. 2026",category:"Продажи",type:"income",amount:2150}
];
let transactions = JSON.parse(localStorage.getItem("gp_transactions") || "null") || demoTransactions.slice();
let tasks = JSON.parse(localStorage.getItem("gp_tasks") || "null") || [
 {name:"Проверить поступления",meta:"Финансы · 09:00",done:true},
 {name:"Связаться с поставщиком",meta:"Склад · 12:30",done:false},
 {name:"Подготовить отчёт за месяц",meta:"Аналитика · 16:00",done:false}
];
const $ = id => document.getElementById(id);
const euro = n => "€" + Number(n).toLocaleString("ru-RU",{maximumFractionDigits:2});
function totals(){let income=transactions.filter(x=>x.type==="income").reduce((a,x)=>a+Number(x.amount),0);let expense=transactions.filter(x=>x.type==="expense").reduce((a,x)=>a+Number(x.amount),0);return {income,expense,profit:income-expense};}
function render(){const t=totals();["totalIncome","financeIncome"].forEach(id=>$(id).textContent=euro(t.income));["totalExpense","financeExpense"].forEach(id=>$(id).textContent=euro(t.expense));["totalProfit","financeBalance"].forEach(id=>$(id).textContent=euro(t.profit));renderRows();renderTasks();}
function renderRows(){const recent=$("recentRows"),all=$("financeRows");const rows=transactions.slice().reverse();recent.innerHTML=rows.slice(0,5).map(x=>`<tr><td><b>${esc(x.name)}</b></td><td>${esc(x.date)}</td><td>${esc(x.category||"Другое")}</td><td class="${x.type==="income"?"amount-positive":"amount-negative"}">${x.type==="income"?"+":"−"}${euro(x.amount)}</td><td><span class="status good">Проведено</span></td></tr>`).join("");all.innerHTML=rows.map(x=>`<tr><td><b>${esc(x.name)}</b></td><td>${esc(x.date)}</td><td>${esc(x.category||"Другое")}</td><td>${x.type==="income"?"Доход":"Расход"}</td><td class="${x.type==="income"?"amount-positive":"amount-negative"}">${x.type==="income"?"+":"−"}${euro(x.amount)}</td></tr>`).join("");}
function renderTasks(){const html=tasks.map((t,i)=>`<label class="task"><input type="checkbox" data-task="${i}" ${t.done?"checked":""}><span class="checkmark"></span><span><b>${esc(t.name)}</b><small>${esc(t.meta||"Без срока")}</small></span></label>`).join("");$("taskList").innerHTML=html;$("planningList").innerHTML=html;document.querySelectorAll("[data-task]").forEach(el=>el.addEventListener("change",()=>{tasks[Number(el.dataset.task)].done=el.checked;localStorage.setItem("gp_tasks",JSON.stringify(tasks));renderTasks();}));}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function showToast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600);}
const titles={overview:"Обзор",finance:"Финансы",inventory:"Склад",customers:"Клиенты",documents:"Документы",analytics:"Аналитика",planning:"Планирование",settings:"Настройки"};
function navigate(page){document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));$("page-"+page).classList.add("active");document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));$("crumbName").textContent=titles[page];$("sidebar").classList.remove("open");window.scrollTo({top:0,behavior:"smooth"});}
document.querySelectorAll(".nav-item").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.page)));
document.querySelectorAll("[data-goto]").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.goto)));
$("menuBtn").onclick=()=>$("sidebar").classList.toggle("open");
$("searchBtn").onclick=()=>{const q=prompt("Что найти в Green Peak?");if(q){const found=transactions.find(x=>x.name.toLowerCase().includes(q.toLowerCase()));showToast(found?`Найдена операция: ${found.name}`:"В демо-данных совпадений нет.");}};
$("helpBtn").onclick=()=>showToast("Центр помощи будет добавлен в следующем обновлении.");
$("chartPeriod").onchange=()=>showToast("Период графика: "+$("chartPeriod").value);
const modal=$("modalBackdrop");
function openModal(title="Новая операция"){ $("modalTitle").textContent=title;$("modalDescription").textContent="Добавьте запись в рабочее пространство.";modal.classList.add("open");}
function closeModal(){modal.classList.remove("open");}
$("quickAdd").onclick=$("financeAdd").onclick=()=>openModal();
$("modalClose").onclick=closeModal;modal.addEventListener("click",e=>{if(e.target===modal)closeModal();});
$("operationForm").addEventListener("submit",e=>{e.preventDefault();const name=$("opName").value.trim(),amount=Number($("opAmount").value);if(!name||!amount||amount<=0)return;transactions.push({name,date:new Date().toLocaleDateString("ru-RU",{day:"2-digit",month:"short",year:"numeric"}),category:$("opCategory").value.trim()||"Другое",type:$("opType").value,amount});localStorage.setItem("gp_transactions",JSON.stringify(transactions));render();e.target.reset();closeModal();showToast("Операция сохранена в этом браузере.");});
$("financeSearch").addEventListener("input",e=>{const q=e.target.value.toLowerCase();$("financeRows").innerHTML=transactions.slice().reverse().filter(x=>(x.name+" "+x.category).toLowerCase().includes(q)).map(x=>`<tr><td><b>${esc(x.name)}</b></td><td>${esc(x.date)}</td><td>${esc(x.category)}</td><td>${x.type==="income"?"Доход":"Расход"}</td><td class="${x.type==="income"?"amount-positive":"amount-negative"}">${x.type==="income"?"+":"−"}${euro(x.amount)}</td></tr>`).join("");});
function addTask(){const name=prompt("Название новой задачи:");if(name&&name.trim()){tasks.push({name:name.trim(),meta:"Добавлено вручную",done:false});localStorage.setItem("gp_tasks",JSON.stringify(tasks));renderTasks();showToast("Задача добавлена.");}}
$("addTask").onclick=$("planningTask").onclick=addTask;
$("addProduct").onclick=()=>showToast("Форма добавления товара появится в следующем этапе.");
$("addCustomer").onclick=()=>showToast("Форма добавления клиента появится в следующем этапе.");
$("addDocument").onclick=()=>showToast("Создание документов будет подключено отдельным модулем.");
$("exportCsv").onclick=()=>{const lines=[["Название","Дата","Категория","Тип","Сумма"],...transactions.map(x=>[x.name,x.date,x.category,x.type,x.amount])];const csv="\uFEFF"+lines.map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(";")).join("\n");const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv;charset=utf-8"}));a.download="green-peak-report.csv";a.click();URL.revokeObjectURL(a.href);};
async function auth(){if(!supabaseClient){showToast("Supabase не загрузился. Проверьте интернет-соединение.");return;}const email=prompt("Введите email для входа или регистрации:");if(!email)return;const password=prompt("Введите пароль (не менее 6 символов):");if(!password)return;try{const {data,error}=await supabaseClient.auth.signInWithPassword({email,password});if(error){const create=confirm("Вход не выполнен. Создать новый аккаунт с этим email?");if(!create)return;const result=await supabaseClient.auth.signUp({email,password});if(result.error)throw result.error;showToast("Аккаунт создан. Проверьте почту для подтверждения.");return;}$("profileName").textContent="Мой аккаунт";$("profileEmail").textContent=data.user.email;showToast("Вы вошли в аккаунт.");}catch(e){showToast(e.message||"Ошибка авторизации.");}}
$("authBtn").onclick=$("settingsAuth").onclick=auth;
if(supabaseClient){supabaseClient.auth.getUser().then(({data})=>{if(data.user){$("profileName").textContent="Мой аккаунт";$("profileEmail").textContent=data.user.email;}});}
render();
